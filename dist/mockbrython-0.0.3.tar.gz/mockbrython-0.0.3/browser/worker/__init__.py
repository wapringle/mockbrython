from browser import _mockbrython


class Worker():

    def __init__(self, worker_id):
        return None

    def bind(self, evt, function):
        pass

    def send(self, message):
        pass
