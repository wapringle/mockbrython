from browser import _mockbrython


def define(tag_name, component_class):
    pass


def get(tag_name):
    return _mockbrython
