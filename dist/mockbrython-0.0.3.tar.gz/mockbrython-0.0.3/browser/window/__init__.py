innerWidth=0
innerHeight=0
def loadImage(*args,**kwargs):
    pass
def requestAnimationFrame(*args,**kwargs):
    pass

