def mark(src):
    # return empty
    return ("",[])
