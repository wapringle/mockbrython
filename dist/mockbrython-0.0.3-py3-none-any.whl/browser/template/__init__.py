from browser.html import _mockbrython

Template = _mockbrython
