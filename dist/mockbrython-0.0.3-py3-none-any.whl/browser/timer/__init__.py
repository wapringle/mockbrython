"""Mock brython timer functions """

def set_timeout(function,ms):
    pass
    
def clear_timeout(timer):
    pass

def set_interval(function,ms):
    function()

def clear_interval(timer):
    pass
def request_animation_frame(function):
    pass

def cancel_animation_frame(id):
    pass
