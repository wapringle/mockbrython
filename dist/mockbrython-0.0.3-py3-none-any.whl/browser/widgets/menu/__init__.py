class Menu():

    def __init__(self, container=None, default_css=True):
        pass

    def add_item(self, label, callback=None):
        pass

    def add_link(self, label, href):
        pass

    def add_menu(self, label):
        return Menu()
