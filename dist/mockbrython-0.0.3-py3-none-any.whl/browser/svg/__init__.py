from browser import _mockbrython

""" SVG emulation """

a = _mockbrython
altGlyph = _mockbrython
altGlyphDef = _mockbrython
altGlyphItem = _mockbrython
animate = _mockbrython
animateColor = _mockbrython
animateMotion = _mockbrython
animateTransform = _mockbrython
circle = _mockbrython
clipPath = _mockbrython
color_profile = _mockbrython
cursor = _mockbrython
defs = _mockbrython
desc = _mockbrython
ellipse = _mockbrython
feBlend = _mockbrython
g = _mockbrython
image = _mockbrython
line = _mockbrython
linearGradient = _mockbrython
marker = _mockbrython
mask = _mockbrython
path = _mockbrython
pattern = _mockbrython
polygon = _mockbrython
polyline = _mockbrython
radialGradient = _mockbrython
rect = _mockbrython
stop = _mockbrython
svg = _mockbrython
text = _mockbrython
tref = _mockbrython
tspan = _mockbrython
use = _mockbrython


